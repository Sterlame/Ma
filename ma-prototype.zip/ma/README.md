# Ma (間)

A distraction-free personal writing tool. "Ma" is the Japanese concept
of purposeful empty space — the pause between notes that gives them
meaning. That's the design brief: a writing surface where the margin
is the feature, not a gap waiting to be filled with toolbars.

Static site, local-first storage, optional background sync to your
own Google Drive. No accounts system, no shared backend — everything
lives in your browser (IndexedDB) and, optionally, your Drive.

## Features (v1 prototype)

- **Local-first editing** — autosaves to IndexedDB every ~600ms, works fully offline
- **Live markdown** — `#`/`##`/`###`, `> quotes`, `- lists`, `**bold**`, `*italic*`, `` `code` `` render as you type; storage is always plain markdown underneath
- **Notebooks** — organize documents into folders that mirror real Drive folders
- **Search** — filter documents by title or tag
- **Focus mode** — dims everything but the current paragraph, hides chrome
- **Three themes** — light (paper), sepia, dark (charcoal)
- **Word count + optional goal** per document
- **Drive sync** — auto-sync every 30s (when connected) + manual "sync" button; documents saved as `.md` files with YAML frontmatter, so they're readable outside the app too
- **Versioning** — deliberately not reinvented; Drive's own file revision history covers "I need yesterday's version"

## Getting started

1. **Backend:** follow [`apps-script/README.md`](apps-script/README.md) to deploy the Apps Script Web App and paste the URL into `js/sync.js`.
2. **Frontend:** push this repo to GitHub, enable GitHub Pages (Settings → Pages → deploy from `main` / root), and visit the resulting URL. Or just open `index.html` locally for offline-only use.
3. Click **connect drive** in the sidebar once the backend URL is set, and approve the Google OAuth prompt.

## Project structure

```
index.html          shell + layout
css/styles.css       design tokens, themes, focus mode
js/db.js             IndexedDB wrapper (notebooks, documents, meta)
js/markdown.js       live markdown rendering + markdown <-> DOM
js/sync.js           Drive sync via the Apps Script backend
js/app.js            app state, events, autosave
apps-script/Code.gs  Drive backend, deployed as a Web App
```

## Design notes

- Type: Source Serif 4 for writing, IBM Plex Mono for UI chrome — the split reinforces "this is a tool" vs. "this is your prose."
- Editor column caps at 680px (620px in focus mode) — margins widen deliberately rather than filling the screen.
- Inline formatting (bold/italic/code) only re-renders on lines the cursor has left, so it never fights your typing.
- Not built: real-time collaboration, rich version history UI, plugin system. Kept out on purpose — this is meant to stay small.

## Known limitations (prototype stage)

- Conflict handling on sync is last-write-wins; fine for a single person across devices, worth revisiting if more people join.
- No offline queueing UI yet — if Drive is unreachable, sync silently retries on the next interval.
- Frontmatter tag editing happens by editing `tags` on the document object directly for now; a proper tag UI is a natural next step.
